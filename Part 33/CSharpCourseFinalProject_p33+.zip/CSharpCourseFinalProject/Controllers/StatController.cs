﻿using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Controllers
{
    public class StatController : IStatController
    {
        public List<StatModel> FindBestSellDays(List<BillDetail> bills)
        {
            throw new NotImplementedException();
        }

        public List<StatModel> FindBestSellItem(List<BillDetail> bills)
        {
            List<StatModel> result = new List<StatModel>();
            foreach (var bill in bills)
            {
                if(bill.Status.CompareTo("Đã thanh toán") == 0)
                {
                    foreach (var item in bill.Cart.SelectedItems)
                    {
                        bool isExisted = false;
                        for(int i = 0; i < result.Count; i++)
                        {
                            if (item.Equals(result[i].Item))
                            {
                                result[i].TotalRevenue += item.NumberOfSelectedItem * item.PriceAfterDiscount;
                                result[i].TotalItem += item.NumberOfSelectedItem;
                                isExisted = true;
                                break;
                            }
                        }
                        if(!isExisted)
                        {
                            var statModel = new StatModel(item, item.NumberOfSelectedItem,
                                item.NumberOfSelectedItem * item.PriceAfterDiscount);
                            result.Add(statModel);
                        }
                    }
                }
            }
            result.Sort();
            return result;
        }

        public List<StatModel> FindDailyRevenue(List<BillDetail> bills)
        {
            throw new NotImplementedException();
        }

        public List<StatModel> FindMonthlyRevenue(List<BillDetail> bills)
        {
            throw new NotImplementedException();
        }

        public List<StatModel> FindMostBoughtCustomer(List<BillDetail> bills)
        {
            throw new NotImplementedException();
        }
    }
}
