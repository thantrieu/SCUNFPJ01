﻿using System.Collections.Generic;
using Models;

namespace Controllers
{
    public interface IStatController
    {
        List<StatModel> FindBestSellItem(List<BillDetail> bills);
        List<StatModel> FindMostBoughtCustomer(List<BillDetail> bills);
        List<StatModel> FindBestSellDays(List<BillDetail> bills);
        List<StatModel> FindMonthlyRevenue(List<BillDetail> bills);
        List<StatModel> FindDailyRevenue(List<BillDetail> bills);
    }
}
