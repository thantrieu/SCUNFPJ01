﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using Controllers;
using Models;
using System.Windows.Forms;

namespace CSharpCourseFinalProject
{
    public partial class AddEditBillFrm : Form
    {
        private List<Item> _items;
        private List<Customer> _customer;
        private IViewController _controller;
        private BillDetail _bill;
        private CommonController _commonController;
        private List<Customer> _searchedCustomerResults;
        private List<Item> _searchedItemResults;
        private IBillController _billController;

        public AddEditBillFrm()
        {
            InitializeComponent();
            CenterToParent();
            _commonController = new CommonController();
            _billController = new BillController();
            _searchedCustomerResults = new List<Customer>();
            _searchedItemResults = new List<Item>();
        }

        public AddEditBillFrm(IViewController controller,
            List<Customer> customers, List<Item> items, BillDetail bill=null) : this()
        {
            _controller = controller;
            _items = items;
            _customer = customers;
            if(bill!=null)
            {
                _bill = bill;
                ShowBillData();
            } else
            {
                _bill = new BillDetail(0);
            }
        }

        private void ShowBillData()
        {
            throw new NotImplementedException();
        }

        private void BtnPayClick(object sender, EventArgs e)
        {
            var paymentView = new PaymentFrm();
            paymentView.Show();
        }

        private void BtnSearchCustomerClick(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(txtSearchCustomer.Text))
            {
                var msg = "Vui lòng nhập tên khách hàng cần tìm.";
                var title = "Lỗi tìm kiếm";
                MessageBox.Show(msg, title, MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else
            {
                _searchedCustomerResults = _commonController.Search(_customer, 
                    new CustomerController().IsCustomerNameMatch, txtSearchCustomer.Text);
                tblSearchedCustomer.Rows.Clear();
                foreach (var customer in _searchedCustomerResults)
                {
                    tblSearchedCustomer.Rows.Add(new object[]
                    {
                            customer.PersonId, customer.FullName.ToString()
                    });
                }
                if (_searchedCustomerResults.Count == 0)
                {
                    var msg = "Không tìm thấy kết quả nào.";
                    var title = "Kết quả tìm kiếm";
                    MessageBox.Show(msg, title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void BtnSearchItemClick(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtSearchItem.Text))
            {
                var msg = "Vui lòng nhập tên mặt hàng cần tìm.";
                var title = "Lỗi tìm kiếm";
                MessageBox.Show(msg, title, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                _searchedItemResults = _commonController.Search(_items,
                    new ItemController().IsItemNameMatch, txtSearchItem.Text);
                tblSearchedItem.Rows.Clear();
                foreach (var item in _searchedItemResults)
                {
                    tblSearchedItem.Rows.Add(new object[]
                    {
                            item.ItemId, item.ItemName, $"{item.Quantity:N0}"
                    });
                }
                if (_searchedItemResults.Count == 0)
                {
                    var msg = "Không tìm thấy kết quả nào.";
                    var title = "Kết quả tìm kiếm";
                    MessageBox.Show(msg, title, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void TblCustomerCellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.RowIndex >= 0 && e.ColumnIndex == tblSearchedCustomer.Columns["tblCustomerColSelect"].Index)
            {
                _bill.Cart.Customer = _searchedCustomerResults[e.RowIndex];
                var customerName = _searchedCustomerResults[e.RowIndex]?.FullName?.ToString();
                labelCustomerName.Text = $"Tên KH: {customerName}";
            }
        }

        private void TblItemCellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == tblSearchedItem.Columns["tblItemColSelect"].Index)
            {
                SelectedItem item = new SelectedItem(_searchedItemResults[e.RowIndex]);
                item.NumberOfSelectedItem = (int)numericSelectedQuantity.Value;
                _billController.UpdateBill(_bill, item);
                ShowBillDetail(item);
                labelTotalItem.Text = $"Tổng SP: {_bill.TotalItem:N0}sp";
                labelTotalAmount.Text = $"Tổng tiền: {_bill.TotalAmount:N0}đ";
                labelTotalDiscount.Text = $"Tổng KM: {_bill.TotalDiscountAmount:N0}đ";
            }
        }

        private void ShowBillDetail(SelectedItem item)
        {
            tblBillDetail.Rows.Add(new object[]
            {
                _bill.BillId, item.ItemId, item.ItemName, $"{item.NumberOfSelectedItem:N0}",
                $"{item.Price:N0}", $"{item.PriceAfterDiscount:N0}", 
                $"{item.NumberOfSelectedItem * item.PriceAfterDiscount:N0}"
            });
        }
    }
}
