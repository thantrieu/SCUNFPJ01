﻿using Models;

namespace Controllers
{
    public class BillController : IBillController
    {
        public void UpdateBill(BillDetail bill, SelectedItem item)
        {
            bill.Cart.SelectedItems.Add(item);
            bill.TotalItem += item.NumberOfSelectedItem;
            bill.TotalAmount += item.NumberOfSelectedItem * item.PriceAfterDiscount;
            if(item.Discount != null)
            {
                bill.TotalDiscountAmount += (int)(item.NumberOfSelectedItem *
                item.Price *(1.0f * item.Discount.DiscountPercent / 100)) +
                item.NumberOfSelectedItem * item.Discount.DiscountPriceAmount;
            }
        }
    }
}
